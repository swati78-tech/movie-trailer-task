import React from "react";
import "./home.css";
import FilterDropdown from "./FilterDropdown";

const Header = ({ data, onSelectLanguage, onSelectGenre }) => {
  const languageOptions = data.languageList || [];
  const genreOptions = [
    "Drama",
    "Action",
    "Comedy",
    "Mystery",
    "Crime",
    "Family",
    "Romance"
  ];

  return (
    <div className="header">
      <div className="title">Movie Trailer</div>
      <div className="buttons-container">
        <button className="button">Coming Soon</button>
        <button className="button">Now Showing</button>
      </div>
      <div className="dropdowns-container">
        <FilterDropdown
          className="dropdown"
          dropdownName={"Fresh"}
          options={["Fresh", "Popular"]}
          onSelect={() => console.log("option selected")}
        />
        <FilterDropdown
          className="dropdown"
          dropdownName={"All Languages"}
          options={languageOptions}
          onSelect={(language) => onSelectLanguage(language)}
        />

        <FilterDropdown
          className="dropdown"
          dropdownName={"All Genre"}
          options={genreOptions}
          onSelect={(genre) => onSelectGenre(genre)}
        />
      </div>
    </div>
  );
};

export default Header;
