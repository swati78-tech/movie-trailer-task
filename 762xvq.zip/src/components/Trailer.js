// Trailer.js
import React from "react";
import "./home.css";

const Trailer = ({ trailerUrl, trailerPosition, closeTrailer }) => {
  return (
    <div
      className="trailer-container"
      style={{
        top: trailerPosition.top - "20%",
        left: trailerPosition.left - "20%",
        bottom: "10%",
        right: "10%"
      }}
    >
      <iframe
        className="trailer-video"
        src={trailerUrl}
        frameBorder="0"
        allowFullScreen
        title="Movie Trailer"
      ></iframe>
      <button className="close-button" onClick={closeTrailer}>
        Close Trailer
      </button>
    </div>
  );
};

export default Trailer;
