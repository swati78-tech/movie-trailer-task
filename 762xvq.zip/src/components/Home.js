import React, { useState, useEffect } from "react";
import "./home.css";
import Header from "./Header";
import Trailer from "./Trailer";

function Home() {
  const [data, setData] = useState([]);
  const [selectedTrailer, setSelectedTrailer] = useState(null);
  const [trailerPosition, setTrailerPosition] = useState({ top: 0, left: 0 });
  const [selectedLanguage, setSelectedLanguage] = useState(null);
  const [selectedGenre, setSelectedGenre] = useState(null);
  const [loading, setLoading] = useState(true); // state for loading
  useEffect(() => {
    const apiUrl = "https://in.bmscdn.com/m6/static/interview-mock/data.json";

    const fetchData = async () => {
      try {
        const response = await fetch(apiUrl);

        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const result = await response.json();
        setData(result);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false); // Set loading to false after fetching data
      }
    };

    fetchData();
  }, []);

  function convertToEmbedUrl(originalUrl) {
    const videoId = originalUrl.match(
      /(?:\/|%3D|v=|vi=)([0-9A-Za-z_-]{11})(?:[%#?&]|$)/
    )[1];

    const embedUrl = `https://www.youtube.com/embed/${videoId}`;
    return embedUrl;
  }

  const showTrailer = (trailerUrl, event) => {
    const embedUrl = convertToEmbedUrl(trailerUrl);
    setSelectedTrailer(embedUrl);

    setTrailerPosition({
      top: event.clientY,
      left: event.clientX,
      bottom: "15px",
      right: "15px"
    });
  };
  const closeTrailer = () => {
    setSelectedTrailer(null);
  };

  // Function to filter movies based on language and genre
  const filterMovies = () => {
    let filteredMovies = Object.values(data.moviesData);

    if (selectedLanguage) {
      filteredMovies = filteredMovies.filter(
        (movie) => movie.EventLanguage === selectedLanguage
      );
    }

    if (selectedGenre) {
      filteredMovies = filteredMovies.filter(
        (movie) => movie.EventGenre === selectedGenre
      );
    }

    return filteredMovies;
  };

  return (
    <div className="App">
      <Header
        data={data}
        onSelectLanguage={(language) => setSelectedLanguage(language)}
        onSelectGenre={(genre) => setSelectedGenre(genre)}
      />
      {selectedTrailer && (
        <Trailer
          trailerUrl={selectedTrailer}
          trailerPosition={trailerPosition}
          closeTrailer={closeTrailer}
        />
        // <div
        //   className="trailer-container"
        //   style={{
        //     top: trailerPosition.top - "15px",
        //     left: trailerPosition.left - "15px",
        //     bottom: "15px",
        //     right: "15px"
        //   }}
        // >
        //   <iframe
        //     className="trailer-video"
        //     src={selectedTrailer}
        //     frameBorder="0"
        //     allowFullScreen
        //     title="Movie Trailer"
        //   ></iframe>
        // </div>
      )}
      <div className="container">
        {data &&
          data.moviesData &&
          filterMovies().map((movie, index) => (
            <div
              key={index}
              className="movie-card"
              onClick={(event) => showTrailer(movie.TrailerURL, event)}
            >
              <img src={movie.EventImageUrl} alt={movie.EventTitle} />
              <h2>{movie.EventTitle}</h2>
            </div>
          ))}
      </div>
    </div>
  );
}

export default Home;
