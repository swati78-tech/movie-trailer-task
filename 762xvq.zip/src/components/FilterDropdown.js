import React, { useState } from "react";
import "./home.css";

const FilterDropdown = ({ dropdownName, options, onSelect }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedOption, setSelectedOption] = useState(null);

  const handleSelect = (option) => {
    setSelectedOption(option);
    onSelect(option);
    setIsOpen(false);
  };

  return (
    <div className="filter-dropdown">
      <button className="dropdown" onClick={() => setIsOpen(!isOpen)}>
        {selectedOption || dropdownName}
      </button>
      {isOpen && (
        <ul>
          {options.map((option) => (
            <li
              className="list-content"
              key={option}
              onClick={() => handleSelect(option)}
            >
              {option}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default FilterDropdown;
